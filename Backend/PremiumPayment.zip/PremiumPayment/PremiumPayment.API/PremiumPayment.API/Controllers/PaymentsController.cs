﻿using Microsoft.AspNetCore.Mvc;
using PremiumPayment.Application.DTOs;
using PremiumPayment.Application.Interfaces;

namespace PremiumPayment.API.Controllers
{
    [Route("api/v1/payments")]
    [ApiController]
    public class PaymentsController : ControllerBase
    {
        IPremiumPaymentService service;
        public PaymentsController(IPremiumPaymentService service)
        {
            this.service = service;
        }

        // POST /api/v1/payments -> Pay Premium
        [HttpPost]
        public async Task<IActionResult> PayPremium(PayPremiumDTO dto)
        {
            var data = await service.PayPremium(dto);
            return CreatedAtAction(nameof(GetPaymentById), new { paymentId = data.PaymentId }, data);
        }

        // GET /api/v1/payments/{paymentId} -> Get Payment Details
        [HttpGet]
        [Route("{paymentId:long}")]
        public async Task<IActionResult> GetPaymentById(long paymentId)
        {
            var data = await service.GetPaymentById(paymentId);
            if (data == null)
                return NotFound(new { msg = $"Payment {paymentId} not found" });
            return Ok(data);
        }

        // GET /api/v1/payments/history/{policyId} -> Payment History
        [HttpGet]
        [Route("history/{policyId:long}")]
        public async Task<IActionResult> GetPaymentHistory(long policyId)
        {
            var data = await service.GetPaymentHistory(policyId);
            return Ok(data);
        }

        // POST /api/v1/payments/verify -> Verify Payment Gateway Response
        [HttpPost]
        [Route("verify")]
        public async Task<IActionResult> VerifyPayment(VerifyPaymentDTO dto)
        {
            var data = await service.VerifyPayment(dto);
            return Ok(data);
        }
    }
}