﻿using Microsoft.AspNetCore.Mvc;
using PremiumPayment.Application.Interfaces;

namespace PremiumPayment.API.Controllers
{
    [Route("api/v1/payments/{paymentId:long}/receipt")]
    [ApiController]
    public class ReceiptsController : ControllerBase
    {
        IPaymentReceiptService service;
        public ReceiptsController(IPaymentReceiptService service)
        {
            this.service = service;
        }

        // GET /api/v1/payments/{paymentId}/receipt -> Download Receipt (PDF)
        [HttpGet]
        public async Task<IActionResult> DownloadReceipt(long paymentId)
        {
            var file = await service.DownloadReceipt(paymentId);
            if (file == null)
                return NotFound(new { msg = $"Receipt not found for payment {paymentId}" });
            return File(file.Content, file.ContentType, file.FileName);
        }

        // POST /api/v1/payments/{paymentId}/receipt/regenerate -> Regenerate Receipt
        [HttpPost]
        [Route("regenerate")]
        public async Task<IActionResult> RegenerateReceipt(long paymentId)
        {
            var data = await service.RegenerateReceipt(paymentId);
            return Ok(data);
        }
    }
}