﻿using Microsoft.EntityFrameworkCore;
using PremiumPayment.Application.Interfaces;
using PremiumPayment.Domain.Entities;
using PremiumPayment.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Infrastructure.Repositories
{
    public class PaymentReceiptRepository : IPaymentReceiptRepository
    {
        ApplicationDbContext db;

        public PaymentReceiptRepository(ApplicationDbContext db)
        {
            this.db = db;
        }

        public async Task<payment_receipt?> GetByPaymentId(long paymentId)
        {
            return await db.payment_receipt
                .FirstOrDefaultAsync(r => r.payment_id == paymentId);
        }

        public async Task Add(payment_receipt receipt)
        {
            await db.payment_receipt.AddAsync(receipt);
            await db.SaveChangesAsync();
        }

        public async Task Update(payment_receipt receipt)
        {
            db.payment_receipt.Update(receipt);
            await db.SaveChangesAsync();
        }
    }
}