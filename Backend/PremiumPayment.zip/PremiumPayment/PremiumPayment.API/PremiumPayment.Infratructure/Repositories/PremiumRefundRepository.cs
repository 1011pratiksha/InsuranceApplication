﻿using Microsoft.EntityFrameworkCore;
using PremiumPayment.Application.Interfaces;
using PremiumPayment.Domain.Entities;
using PremiumPayment.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Infrastructure.Repositories
{
    public class PremiumRefundRepository : IPremiumRefundRepository
    {
        ApplicationDbContext db;

        public PremiumRefundRepository(ApplicationDbContext db)
        {
            this.db = db;
        }

        public async Task<premium_refund?> GetById(long refundId)
        {
            return await db.premium_refund
                .FirstOrDefaultAsync(r => r.refund_id == refundId);
        }

        public async Task Add(premium_refund refund)
        {
            await db.premium_refund.AddAsync(refund);
            await db.SaveChangesAsync();
        }

        public async Task Update(premium_refund refund)
        {
            db.premium_refund.Update(refund);
            await db.SaveChangesAsync();
        }
    }
}