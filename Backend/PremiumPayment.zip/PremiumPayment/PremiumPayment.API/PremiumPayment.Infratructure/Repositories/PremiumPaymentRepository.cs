﻿using Microsoft.EntityFrameworkCore;
using PremiumPayment.Application.Interfaces;
using PremiumPayment.Domain.Constants;
using PremiumPayment.Domain.Entities;
using PremiumPayment.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Infrastructure.Repositories
{
    public class PremiumPaymentRepository : IPremiumPaymentRepository
    {
        ApplicationDbContext db;

        public PremiumPaymentRepository(ApplicationDbContext db)
        {
            this.db = db;
        }

        public async Task<premium_payment?> GetById(long paymentId)
        {
            return await db.premium_payment
                .Include(p => p.payment_receipt)
                .FirstOrDefaultAsync(p => p.payment_id == paymentId);
        }

        public async Task<IEnumerable<premium_payment>> GetByPolicyId(long policyId)
        {
            return await db.premium_payment
                .Include(p => p.payment_receipt)
                .Where(p => p.policy_id == policyId)
                .OrderByDescending(p => p.payment_date)
                .ToListAsync();
        }

        public async Task Add(premium_payment payment)
        {
            await db.premium_payment.AddAsync(payment);
            await db.SaveChangesAsync();
        }

        public async Task Update(premium_payment payment)
        {
            db.premium_payment.Update(payment);
            await db.SaveChangesAsync();
        }

        public async Task<bool> ExistsByScheduleId(long scheduleId)
        {
            // Only payments that block a new attempt count.
            // Failed / Cancelled / Refunded do not, because BRD says a failed payment can be retried.
            return await db.premium_payment.AnyAsync(p =>
                p.schedule_id == scheduleId &&
                (p.payment_status == payment_status_values.Initiated ||
                 p.payment_status == payment_status_values.Pending ||
                 p.payment_status == payment_status_values.Success));
        }
    }
}