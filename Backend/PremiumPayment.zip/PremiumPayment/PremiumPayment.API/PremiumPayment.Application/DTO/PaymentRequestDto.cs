﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Application.DTO
{
    public class PaymentRequestDto
    {
        [Required]
        public long schedule_id { get; set; }

        [Required]
        public long policy_id { get; set; }

        [Required]
        [Range(0.01, 9999999999999.99)]
        public decimal amount_paid { get; set; }

        [Required]
        public string payment_mode { get; set; } = string.Empty;
    }
}
