﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Application.DTO
{
    public class VerifyPaymentDto
    {
        [Required] public long payment_id { get; set; }
        [Required] public string transaction_reference { get; set; } = string.Empty;
        [Required] public string gateway_status { get; set; } = string.Empty; // "Success" or "Failed"
    }
}
