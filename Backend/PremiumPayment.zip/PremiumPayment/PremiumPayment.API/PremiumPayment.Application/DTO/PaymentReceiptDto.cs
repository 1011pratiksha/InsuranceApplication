﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Application.DTO
{
    public class PaymentReceiptDto
    {
        public long receipt_id { get; set; }

        public long payment_id { get; set; }

        public string receipt_number { get; set; } = string.Empty;

        public DateTime receipt_date { get; set; }

        public string receipt_path { get; set; } = string.Empty;
    }
}
