﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Application.DTO
{
    public class PaymentResponseDto
    {
        public long payment_id { get; set; }

        public long schedule_id { get; set; }

        public long policy_id { get; set; }

        public DateTime payment_date { get; set; }

        public decimal amount_paid { get; set; }

        public string payment_mode { get; set; } = string.Empty;

        public string transaction_reference { get; set; } = string.Empty;

        public string payment_status { get; set; } = string.Empty;
    }
}
