﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Application.DTO
{
    public class RefundResponseDto
    {
        public long refund_id { get; set; }

        public long payment_id { get; set; }

        public decimal refund_amount { get; set; }

        public DateTime refund_date { get; set; }

        public string refund_status { get; set; } = string.Empty;

        public long? approved_by { get; set; }
    }
}
