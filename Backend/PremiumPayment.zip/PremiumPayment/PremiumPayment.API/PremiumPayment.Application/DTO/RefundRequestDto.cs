﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PremiumPayment.Application.DTO
{
    public class RefundRequestDto
    {
        [Required]
        public long payment_id { get; set; }

        [Required]
        [Range(0.01, 9999999999999.99)]
        public decimal refund_amount { get; set; }
    }
}
